package com.example.nasa_solarwomen;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;


public class AlarmReceiver extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        int requestCode = intent.getIntExtra("requestCode", 0);

        Toast.makeText(context, "Alarm : "+requestCode, Toast.LENGTH_LONG).show();
//        Toast.makeText(context, "id : "+intent.getStringExtra("id"), Toast.LENGTH_LONG).show();

        if (requestCode==4){

//            final int flags = PendingIntent.FLAG_CANCEL_CURRENT; // ONE_SHOT：PendingIntent只使用一次；CANCEL_CURRENT：PendingIntent執行前會先結束掉之前的；NO_CREATE：沿用先前的PendingIntent，不建立新的PendingIntent；UPDATE_CURRENT：更新先前PendingIntent所帶的額外資料，並繼續沿用
//            final PendingIntent pendingIntent = PendingIntent.getActivity(context.getApplicationContext(), requestCode, intent, flags); // 取得PendingIntent
//            final NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE5); // 取得系統的通知服務
//            final Notification notification = new Notification.Builder(context.getApplicationContext()).setSmallIcon(R.drawable.ic_launcher_foreground).setContentTitle("內容標題").setContentText("內容文字").setContentIntent(pendingIntent).build(); // 建立通知
//            notificationManager.notify(requestCode, notification); // 發送通知
        }

//        Intent i = new Intent(context, LoginActivity.class);
//        i.putExtra("id", intent.getStringExtra("id"));
//        i.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT
//                | Intent.FLAG_ACTIVITY_NEW_TASK);
//        context.startActivity(i);


    }



}
