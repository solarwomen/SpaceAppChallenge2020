package com.example.nasa_solarwomen;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class ScheduleActivity extends AppCompatActivity {

    private sessionManager sessionHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);
        sessionHelper = new sessionManager(getApplicationContext());

        Bundle b =this.getIntent().getExtras();

        String dockerGroupNum = b.getString("docking");
        String landGroupNum = b.getString("landing");
        String taskGroupNum =b.getString("task");
        String noTaskGroupNum = b.getString("noTask");


        sessionHelper.setDockingGroupTag(dockerGroupNum);
        sessionHelper.setLandGroupTag(landGroupNum);
        sessionHelper.setTaskGroupTag(taskGroupNum);
        sessionHelper.setNoTaskGroupTag(noTaskGroupNum);
        sessionHelper.setTaskOrNotTag("1");


//        String dockerGroupNum = sessionHelper.getDockingGroupTag();
//        String landGroupNum = sessionHelper.getLandGroupTag();
//        String taskGroupNum = sessionHelper.getNoTaskGroupTag();
//        String noTaskGroupNum = sessionHelper.getNoTaskGroupTag();

        ArrayList<View> mPages = new ArrayList<>();

        mPages.add(new Pages(this, 0));
        mPages.add(new Pages(this, 1));
        mPages.add(new Pages(this, 2));
        String num = "0";
        mPages.add(new Pages(this, 3));
        mPages.add(new Pages( this, 4));
        mPages.add(new Pages( this,5));

        ViewPager viewPager = findViewById(R.id.mViewPager);
        TabLayout tab = findViewById(R.id.tab);
        PagesAdapter myPagerAdapter = new PagesAdapter(mPages);

        tab.setupWithViewPager(viewPager);//將TabLayout綁定給ViewPager
        viewPager.setAdapter(myPagerAdapter);//綁定適配器
        viewPager.setCurrentItem(0);//指定跳到某頁，一定得設置在setAdapter後面
    }
}
