package com.example.nasa_solarwomen;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

public class MealActivity extends Activity {

    private RequestQueue queue;
    private sessionManager sessionHelper;

    private TextView meal_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal);
//        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
//        getSupportActionBar().setCustomView(R.layout.abs_layout);
        initModule();
        initLayout();
    }

    private void initModule() {
        queue = Volley.newRequestQueue(MealActivity.this);
        sessionHelper = new sessionManager(getApplicationContext());
    }

    private void initLayout() {
        meal_text = (TextView)findViewById(R.id.text_meal);
    }

//    private ArrayList getFood(){
//        String authUrl = serverURL + "/getFood";
//        JSONObject request = new JSONObject();
//        final JSONObject[] mealList = {new JSONObject()};
//        JsonObjectRequest strReq = new JsonObjectRequest(Request.Method.POST, authUrl, request,
//                new Response.Listener<JSONObject>() {
//
//                    @Override
//                    public void onResponse(JSONObject responseObj) {
//                        try {
//
//                            mealList = responseObj.getJSONArray("food");
//
//                        } catch (Exception e) {
//                            Toast.makeText(getApplicationContext(), "get meal fail", Toast.LENGTH_LONG).show();
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
//                    }
//                }
//        );
//        queue.add(strReq);
//        return
//    }
}
