package com.example.nasa_solarwomen;

public class Setting {
    static final String serverURL = "http://35.224.126.147:3000";
}
