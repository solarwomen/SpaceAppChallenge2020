package com.example.nasa_solarwomen;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AlarmActivity extends AppCompatActivity {
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)

    public static final String inputFormat = "HH:mm";

    private Date date;
    private Date dateCompareOne;
    private Date dateCompareTwo;

    private String[] timeOne = {"6:00", "7:00", "12:00", "13:00", "14:00", "16:00", "17:00", "18:00", "19:00", "23:00"};
    private String compareStringTwo = "1:45";

    SimpleDateFormat inputParser = new SimpleDateFormat(inputFormat, Locale.TAIWAN);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int[] hours = {6,7,12,13,14,16,16,17,18,19,23};
        int[] mins = {0, 0, 0, 0, 0, 0, 30, 0, 0, 0, 0};
        // 設定於 1 分鐘後執行
//        cal.add(Calendar.MINUTE, 1);
        Calendar cal;
        PendingIntent pi;
        ArrayList<PendingIntent> intentArray = new ArrayList<PendingIntent>();
        AlarmManager am;
        int i=compareDates();
        Toast.makeText(this, "i : "+i, Toast.LENGTH_SHORT).show();
        if (i<11){
            for (i=4; i < 11; i++){
                cal = Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY, hours[i]);
                cal.set(Calendar.MINUTE, mins[i]);

                Intent intent = new Intent(this, AlarmReceiver.class);
                intent.putExtra("requestCode", i);

                am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                pi = PendingIntent.getBroadcast(this, i, intent, 0);

                am.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                intentArray.add(pi);
//                Toast.makeText(this, "set Alarm Success", Toast.LENGTH_LONG).show();
            }
        }

        Intent intent_1 = new Intent(this, AlarmReceiver.class);//the same as up
        boolean isWorking = (PendingIntent.getBroadcast(this, 0, intent_1, PendingIntent.FLAG_NO_CREATE) != null);//just changed the flag
        if (isWorking){
            Toast.makeText(this, "alarm is working...", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "alarm is not working...", Toast.LENGTH_LONG).show();
        }


    }

    private int compareDates(){
        Calendar now = Calendar.getInstance();

        int hour = now.get(Calendar.HOUR);
        int minute = now.get(Calendar.MINUTE);

        date = parseDate(hour + ":" + minute);

        for (int i=0; i<11; i++){
            Date dateTime1 = parseDate(timeOne[i]);
            Date dateTime2 = parseDate(timeOne[i+1]);
            if ( date.after(dateTime1) || date.before(dateTime2)) {
                Toast.makeText(this, "function i : "+i, Toast.LENGTH_SHORT).show();;
                return i;
            }else{
                continue;
            }
        }
        return 11;
    }

    private Date parseDate(String date) {

        try {
            return inputParser.parse(date);
        } catch (java.text.ParseException e) {
            return new Date(0);
        }
    }
}
