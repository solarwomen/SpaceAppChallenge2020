package com.example.nasa_solarwomen;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import static com.example.nasa_solarwomen.Setting.serverURL;

public class RegisterActivity extends Activity {

    private RequestQueue queue;
    private sessionManager sessionHelper;

    private EditText register_acc_text;
    private EditText register_pwd_text;
    private EditText register_confirm_pwd_text;
    private Button register_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
//        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
//        getSupportActionBar().setCustomView(R.layout.abs_layout);
        initModule();
        initLayout();
    }

    private void initModule() {
        queue = Volley.newRequestQueue(RegisterActivity.this);
        sessionHelper = new sessionManager(getApplicationContext());
    }

    private void initLayout() {
        register_acc_text = (EditText) findViewById(R.id.register_acc_text);
        register_pwd_text = (EditText) findViewById(R.id.register_pwd_text);
        register_confirm_pwd_text = (EditText) findViewById(R.id.register_confirm_pwd_text);
        register_btn = (Button) findViewById(R.id.register_btn);
        register_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                if (register_pwd_text.getText() == register_confirm_pwd_text.getText()){
//                    attemptRegister();
//                }else{
//                    Toast.makeText(RegisterActivity.this, "please check password again!!", Toast.LENGTH_SHORT).show();
//                }
//                attemptRegister();
                Intent intent = new Intent();
                intent.setClass(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    private void attemptRegister() {
        String authUrl = serverURL + "/register";
        JSONObject request = new JSONObject();
        try {
            request.put("username", register_acc_text.getText());
            request.put("password", register_pwd_text.getText());
        } catch (
        JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest strReq = new JsonObjectRequest(Request.Method.POST, authUrl, request,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject responseObj) {
                        try {
                            Log.d("Process status", "login by 4g 4");
                            String result = responseObj.getString("result");
                            Log.d("Process status", "login by 4g 5");
                            Log.d("result : ", result);
                            if (result=="true"){
                                Intent intent = new Intent();
                                intent.setClass(RegisterActivity.this, LoginActivity.class);
                                startActivity(intent);
                            }

                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "authenticated fail", Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Process status", "login by 4g can not post");
                        System.out.println(error.toString());
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }
        );
        strReq.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        queue.add(strReq);
    }
}
