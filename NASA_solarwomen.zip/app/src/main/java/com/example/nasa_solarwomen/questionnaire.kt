package com.example.nasa_solarwomen

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Parcelable
import android.util.Log
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.quickbirdstudios.surveykit.AnswerFormat
import com.quickbirdstudios.surveykit.FinishReason
import com.quickbirdstudios.surveykit.NavigableOrderedTask
import com.quickbirdstudios.surveykit.SurveyTheme
import com.quickbirdstudios.surveykit.TextChoice
import com.quickbirdstudios.surveykit.result.TaskResult
import com.quickbirdstudios.surveykit.steps.CompletionStep
import com.quickbirdstudios.surveykit.steps.InstructionStep
import com.quickbirdstudios.surveykit.steps.QuestionStep
import com.quickbirdstudios.surveykit.survey.SurveyView
import kotlinx.android.parcel.Parcelize
import java.util.*


class questionnaire : AppCompatActivity() {

    protected lateinit var survey: SurveyView
    private lateinit var container: ViewGroup
    private lateinit var session_Helper: sessionManager
//    private val session_manager = sessionManager(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_questionnaire)

        survey = findViewById(R.id.survey_view)
        container = findViewById(R.id.surveyContainer)

        setupSurvey(survey)

    }

    private fun setupSurvey(surveyView: SurveyView) {
        val steps = listOf(
                InstructionStep(
                        title = this.resources.getString(R.string.intro_title),
                        text = this.resources.getString(R.string.intro_text),
                        buttonText = this.resources.getString(R.string.intro_start)
                ),
                QuestionStep(
                        title = this.resources.getString(R.string.Q2_title),
                        text = this.resources.getString(R.string.question_text),
                        answerFormat = AnswerFormat.SingleChoiceAnswerFormat(
                                textChoices = listOf(
                                        TextChoice(this.resources.getString(R.string.Q2_opt1), "0"),
                                        TextChoice(this.resources.getString(R.string.Q2_opt2), "1"),
                                        TextChoice(this.resources.getString(R.string.Q2_opt3), "2")
                                )
                        )
                ),
                QuestionStep(
                        title = this.resources.getString(R.string.Q3_title),
                        text = this.resources.getString(R.string.question_text),
                        answerFormat = AnswerFormat.DateAnswerFormat()
                ),
                QuestionStep(
                        title = this.resources.getString(R.string.Q4_title),
                        text = this.resources.getString(R.string.question_text),
                        answerFormat = AnswerFormat.SingleChoiceAnswerFormat(
                                textChoices = listOf(
                                        TextChoice(this.resources.getString(R.string.Q4_opt1), "0"),
                                        TextChoice(this.resources.getString(R.string.Q4_opt2), "1"),
                                        TextChoice(this.resources.getString(R.string.Q4_opt3), "2"),
                                        TextChoice(this.resources.getString(R.string.Q4_opt4), "3"),
                                        TextChoice(this.resources.getString(R.string.Q4_opt5), "4")
                                )
                        )
                ),
                QuestionStep(
                        title = this.resources.getString(R.string.Q5_title),
                        text = this.resources.getString(R.string.question_text),
                        answerFormat = AnswerFormat.DateAnswerFormat()
                ),
                QuestionStep(
                        title = this.resources.getString(R.string.Q6_title),
                        text = this.resources.getString(R.string.question_text),
                        answerFormat = AnswerFormat.SingleChoiceAnswerFormat(
                                textChoices = listOf(
                                        TextChoice(this.resources.getString(R.string.Q6_opt1), "0"),
                                        TextChoice(this.resources.getString(R.string.Q6_opt2), "1"),
                                        TextChoice(this.resources.getString(R.string.Q6_opt3), "2")
                                )
                        )
                ),
                QuestionStep(
                        title = this.resources.getString(R.string.Q7_title),
                        text = this.resources.getString(R.string.question_text),
                        answerFormat = AnswerFormat.SingleChoiceAnswerFormat(
                                textChoices = listOf(
                                        TextChoice(this.resources.getString(R.string.Q7_opt1), "0"),
                                        TextChoice(this.resources.getString(R.string.Q7_opt2), "1")
                                )
                        )
                ),
                CompletionStep(
                        title = this.resources.getString(R.string.finish_question_title),
                        text = this.resources.getString(R.string.finish_question_text),
                        buttonText = this.resources.getString(R.string.finish_question_submit)
                )
        )
        val task = NavigableOrderedTask(steps = steps)
//        task.setNavigationRule(
//                steps[5].id,
//                NavigationRule.DirectStepNavigationRule(
//                        destinationStepStepIdentifier = steps[6].id
//                )
//        )
//        task.setNavigationRule(
//                steps[7].id,
//                NavigationRule.ConditionalDirectionStepNavigationRule(
//                        resultToStepIdentifierMapper = { input ->
//                            when (input) {
//                                "Ja" -> steps[7].id
//                                "Nein" -> steps[0].id
//                                else -> null
//                            }
//                        }
//                )
//        )
        surveyView.onSurveyFinish = { taskResult: TaskResult, reason: FinishReason ->
            if (reason == FinishReason.Completed) {
                var intent = Intent(this, ScheduleActivity::class.java)

//                var bundle = Bundle()
//                Log.i("bundle", "noTask"+taskResult.results.get(1).results.firstOrNull()?.stringIdentifier.toString());
//                Log.i("bundle", "docking"+taskResult.results.get(1).results.firstOrNull()?.stringIdentifier.toString());
//                Log.i("bundle", "landing"+taskResult.results.get(1).results.firstOrNull()?.stringIdentifier.toString());
//                Log.i("bundle", "task"+taskResult.results.get(1).results.firstOrNull()?.stringIdentifier.toString());
//
//                bundle.putString("noTask",taskResult.results.get(1).results.firstOrNull()?.stringIdentifier.toString())
//                bundle.putString("docking",taskResult.results.get(3).results.firstOrNull()?.stringIdentifier.toString())
//                bundle.putString("landing",taskResult.results.get(5).results.firstOrNull()?.stringIdentifier.toString())
//                bundle.putString("task",taskResult.results.get(6).results.firstOrNull()?.stringIdentifier.toString())

                intent.putExtra("noTask",taskResult.results.get(1).results.firstOrNull()?.stringIdentifier.toString())
                intent.putExtra("docking",taskResult.results.get(3).results.firstOrNull()?.stringIdentifier.toString())
                intent.putExtra("landing",taskResult.results.get(5).results.firstOrNull()?.stringIdentifier.toString())
                intent.putExtra("task",taskResult.results.get(6).results.firstOrNull()?.stringIdentifier.toString())

                startActivity(intent)
            }
        }
        val configuration = SurveyTheme(
                themeColorDark = ContextCompat.getColor(this, R.color.cyan_normal),
                themeColor = ContextCompat.getColor(this, R.color.cyan_normal),
                textColor = ContextCompat.getColor(this, R.color.cyan_text)
        )
        surveyView.start(task, configuration)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return if (keyCode == KeyEvent.KEYCODE_BACK) {
            survey.backPressed()
            true
        } else false
    }

}




fun Context.toast(message: CharSequence) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()