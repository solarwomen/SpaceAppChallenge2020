package com.example.nasa_solarwomen;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class Pages extends RelativeLayout {//繼承別的Layout亦可

    private RadioButton radioSexButton;


    private sessionManager sessionHelper;

    public Pages(Context context, int pageNumber) {

        super(context);
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.pages, null);//連接頁面
        sessionHelper = new sessionManager(context.getApplicationContext());
        String roleNumber;
        ImageView schedule_image = view.findViewById(R.id.schedule_image);//取得頁面元件
        Spinner spinner_food = view.findViewById(R.id.spinner_food);
        Button food_btn = view.findViewById(R.id.food_btn);
        final RadioGroup rg_work = view.findViewById(R.id.rg_work);
        final RadioButton radiobtn_work_morning = view.findViewById(R.id.radiobtn_work_morning);
        final RadioButton radiobtn_work_afternoon = view.findViewById(R.id.radiobtn_work_afternoon);
        final RadioButton radiobtn_no_work = view.findViewById(R.id.radiobtn_no_work);

        Button work_btn = view.findViewById(R.id.work_btn);
        TextView weekly_txt = view.findViewById(R.id.weekly_txt);

        if (pageNumber==0){
            roleNumber = sessionHelper.getDockingGroupTag();
            if (roleNumber.equals("0")){
                schedule_image.setImageResource(R.drawable.docking_arrival_0);
            }else if (roleNumber.equals("1")){
                schedule_image.setImageResource(R.drawable.docking_arrival_1);
            }else if (roleNumber.equals("2")){
                schedule_image.setImageResource(R.drawable.docking_arrival_2);
            }else if (roleNumber.equals("3")){
                schedule_image.setImageResource(R.drawable.docking_arrival_3);
            }else {
                schedule_image.setImageResource(R.drawable.docking_arrival_4);
            }
        }else if (pageNumber==1){
            roleNumber = sessionHelper.getLandGroupTag();
            if (roleNumber.equals("0")){
                schedule_image.setImageResource(R.drawable.landing_0);
            }else if (roleNumber.equals("1")){
                schedule_image.setImageResource(R.drawable.landing_1);
            }else if (roleNumber.equals("2")){
                schedule_image.setImageResource(R.drawable.landing_2);
            }else{
                schedule_image.setImageResource(R.drawable.ic_launcher_foreground);
            }
        }else if (pageNumber==2){
            roleNumber = sessionHelper.getTaskOrNotTag();

            if (roleNumber.equals("0")){
                String role = sessionHelper.getNoTaskGroupTag();
                if (role.equals("0")){
                    schedule_image.setImageResource(R.drawable.europe);
                }else if (role.equals("1")){
                    schedule_image.setImageResource(R.drawable.north_america);
                }else{
                    schedule_image.setImageResource(R.drawable.asia_russia);
                }


            }else if (roleNumber.equals("1")){
                String role = sessionHelper.getTaskGroupTag();
                if (role.equals("0")){
                    schedule_image.setImageResource(R.drawable.task_afternoon_after12);
                }else{
                    schedule_image.setImageResource(R.drawable.ic_launcher_foreground);
                }
            }

        }else if (pageNumber==3){
            radiobtn_work_morning.setVisibility(View.VISIBLE);
            radiobtn_work_afternoon.setVisibility(View.VISIBLE);
            radiobtn_no_work.setVisibility(View.VISIBLE);
            work_btn.setVisibility(View.VISIBLE);
            work_btn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {
                    // get selected radio button from radioGroup
                    int selectedId = rg_work.getCheckedRadioButtonId();
                    if (selectedId==0){
                        sessionHelper.setTaskOrNotTag("1");
                        sessionHelper.setTaskGroupTag("0");
                    }else if (selectedId==1){
                        sessionHelper.setTaskOrNotTag("1");
                        sessionHelper.setTaskGroupTag("1");
                    }else{
                        sessionHelper.setTaskOrNotTag("0");
                    }

                }
            });
            rg_work.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {

                    View radioButton = rg_work.findViewById(checkedId);
                    int index = rg_work.indexOfChild(radioButton);
                    switch (index) {
                        case 0:
                            radiobtn_work_afternoon.setChecked(false);
                            radiobtn_no_work.setChecked(false);// perform your action here
                            break;
                        case 1:
                            radiobtn_work_morning.setChecked(false);
                            radiobtn_no_work.setChecked(false);
                            // perform your action here
                            break;
                        case 2:
                            radiobtn_work_morning.setChecked(false);
                            radiobtn_work_afternoon.setChecked(false);
                            // perform your action here
                            break;
                    }
                }
            });
        }else if (pageNumber==4){
            spinner_food.setVisibility(View.VISIBLE);
            food_btn.setVisibility(View.VISIBLE);
            final String[] meal = {"Yogurt,fruit","Apple","White rice", "Corn, whole kernel", "Broccoli", "Carrot coins", "Mushrooms, fried", "Cranberry", "Tomato", "Lamb", "Beaf", "Pork", "Others"};
            ArrayAdapter<String> mealLunch = new ArrayAdapter<>(getContext(),
                    android.R.layout.simple_spinner_dropdown_item,
                    meal);spinner_food.setAdapter(mealLunch);
        }else{
            weekly_txt.setVisibility(View.VISIBLE);
        }

        addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        //將元件放入ViewPager
    }

}
