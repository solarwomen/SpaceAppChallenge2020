package com.example.nasa_solarwomen;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

public class LoginActivity extends AppCompatActivity {

    private RequestQueue queue;
    private sessionManager sessionHelper;

    private UserLoginTask AuthTask = null;
    private EditText login_acc_text;
    private EditText login_pwd_text;
    private Button login_btn;
    private TextView login_register_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
//        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
//        getSupportActionBar().setCustomView(R.layout.abs_layout);
        initModule();
        initLayout();
    }

    private void initModule(){
        queue = Volley.newRequestQueue(LoginActivity.this);
        sessionHelper = new sessionManager(getApplicationContext());
    }

    private void initLayout(){
        login_acc_text = (EditText) findViewById(R.id.login_acc_text);
        //populateAutoComplete();
        login_pwd_text = (EditText) findViewById(R.id.login_pwd_text);
        login_pwd_text.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == R.id.login_btn || id == EditorInfo.IME_NULL) {
                    attemptLogin();
                    return true;
                }
                return false;
            }
        });

        login_btn = (Button) findViewById(R.id.login_btn);
        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptLogin();
            }
        });
        login_register_text = (TextView) findViewById(R.id.login_register_text);
        login_register_text.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
//        LoginFormView = findViewById(R.id.login_form);
//        ProgressView = findViewById(R.id.login_progress);
    }

    /**
     * Attempts to sign in or register the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    private void attemptLogin() {
        Intent intent = new Intent();
        intent.setClass(LoginActivity.this, questionnaire.class);
        startActivity(intent);
//        if (AuthTask != null) {
//            return;
//        }
//        // Reset errors.
//        login_acc_text.setError(null);
//        login_pwd_text.setError(null);
//        Log.d("Process status", "attempt login 3");
//        // Store values at the time of the login attempt.
//        String email = login_acc_text.getText().toString();
//        String password = login_pwd_text.getText().toString();
//        boolean cancel = false;
//        View focusView = null;
//
//        // Check for a valid password, if the user entered one.
////        if (!TextUtils.isEmpty(password) && !isPasswordValid(password)) {
////            login_pwd_text.setError(getString(R.string.error_invalid_password));
////            focusView = login_pwd_text;
////            cancel = true;
////        }
//
//        if (cancel) {
//            // There was an error; don't attempt login and focus the first
//            // form field with an error.
//            focusView.requestFocus();
//        } else {
//            // Show a progress spinner, and kick off a background task to
//            // perform the user login attempt.
////            showProgress(true);
//            AuthTask = new UserLoginTask(email, password);
//            AuthTask.execute((Void) null);
//        }
    }

    private boolean isPasswordValid(String password) {
        //TODO: Replace this with your own logic
        return password.length() > 4;
    }

    private void loginBy4G (final String id, String pw){
        Intent intent = new Intent();
        intent.setClass(LoginActivity.this, questionnaire.class);
        startActivity(intent);
//
//        String authUrl = serverURL + "/";
//        JSONObject request = new JSONObject();
//        try {
//            request.put("name", id);
//            request.put("password", pw);
//        } catch (
//        JSONException e) {
//            e.printStackTrace();
//        }
//        JsonObjectRequest strReq = new JsonObjectRequest(Request.Method.POST, authUrl, request,
//                new Response.Listener<JSONObject>() {
//
//                    @Override
//                    public void onResponse(JSONObject responseObj) {
//                        try {
//                            Log.d("Process status", "login by 4g 4");
//                            String group = responseObj.getString("group");
//                            Log.d("Process status", "login by 4g 5");
//                            Log.d("group : ", group);
//                            sessionHelper.setUserName(id);
//                            sessionHelper.setGroup(group);
//                            Intent intent = new Intent();
//                            intent.setClass(LoginActivity.this, questionnaire.class);
//                            startActivity(intent);
//
//                        } catch (Exception e) {
//                            Toast.makeText(getApplicationContext(), "authenticated fail", Toast.LENGTH_LONG).show();
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Log.d("Process status", "login by 4g can not post");
//                        System.out.println(error.toString());
//                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
//                    }
//                }
//        );
//            queue.add(strReq);
    }

    /**
     * Represents an asynchronous login/registration task used to authenticate
     * the user.
     */
    public class UserLoginTask extends AsyncTask<Void, Void, Boolean> {

        private final String Email;
        private final String Password;

        UserLoginTask(String email, String password) {
            Email = email;
            Password = password;
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // TODO: attempt authentication against a network service.
            loginBy4G(Email,Password);
            try {
                // Simulate network access.
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                return false;
            }

            // TODO: register the new account here.
            return true;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            AuthTask = null;
//            showProgress(false);

            if (success) {
                finish();
            } else {
//                mPasswordView.setError(getString(R.string.error_incorrect_password));
//                mPasswordView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            AuthTask = null;
//            showProgress(false);
        }
    }

}
