package com.example.nasa_solarwomen;

import android.content.Context;
import android.content.SharedPreferences;

public class sessionManager {
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    private static String userNameTag = "userName";
    private static String dockingGroupTag = "dockingGroup";
    private static String landGroupTag = "landGroup";
    private static String taskGroupTag = "taskGroup";
    private static String noTaskGroupTag = "noTaskGroup";
    private static String taskOrNotTag = "taskOrNot";

    sessionManager(Context context){

        int PRIVATE_MODE = 0;
        String prefName = "LoginSession";
        pref = context.getSharedPreferences(prefName, PRIVATE_MODE);
        editor = pref.edit();
        editor.apply();
    }

    String getUserName(){
        return pref.getString(userNameTag, "not exist");
    }
    void setUserNameTag(String userName) {
        editor.putString(userNameTag, userName);
        editor.commit();
    }

    String getDockingGroupTag() { return pref.getString(dockingGroupTag, "not avaliable");}
    void setDockingGroupTag(String dockingGroup) {
        editor.putString(dockingGroupTag, dockingGroup);
        editor.commit();
    }

    String getLandGroupTag() { return pref.getString(landGroupTag, "not avaliable");}
    void setLandGroupTag(String landGroup) {
        editor.putString(landGroupTag, landGroup);
        editor.commit();
    }

    String getTaskGroupTag() { return pref.getString(taskGroupTag, "not avaliable");}
    void setTaskGroupTag(String taskGroup) {
        editor.putString(taskGroupTag, taskGroup);
        editor.commit();
    }

    String getNoTaskGroupTag() { return pref.getString(noTaskGroupTag, "not avaliable");}
    void setNoTaskGroupTag(String noTaskGroup) {
        editor.putString(noTaskGroupTag, noTaskGroup);
        editor.commit();
    }

    String getTaskOrNotTag() { return pref.getString(taskOrNotTag, "not avaliable");}
    void setTaskOrNotTag(String taskOrNot) {
        editor.putString(taskOrNotTag, taskOrNot);
        editor.commit();
    }
}
